Run EDUs segmentation: 
python modelrunner.py -train train_file -dev dev_file -test test_file -predicted_answers prediction_file

requirements: pytorch and pytorch_transformers